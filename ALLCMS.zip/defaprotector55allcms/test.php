<?php include('includetop.php'); ?>
<video controls src="http://www.juthawong.com/tosp.mp4"></video>
<?php include('includebottom.php');
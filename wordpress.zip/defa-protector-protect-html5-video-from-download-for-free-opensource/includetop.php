<?php
ob_start();
?>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" >


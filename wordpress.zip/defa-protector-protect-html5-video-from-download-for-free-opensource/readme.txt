=== Defa Protector Platinum ===
Contributors: Juthawong Naisanguansee
Donate link: http://www.juthawong.com/donate
Tags: Defa Protector,Protect HTML5 Video From Downloaded,chrome,browser,idm,download,video,grabber,stop,download,prevent,block,firewall
Requires at least: 3.3
Tested up to: 4.1
Stable tag: 5.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Protect your html5 video from being downloaded or stolen automatically with the latest technology. 

== Description ==

Protect your html5 video from being downloaded or stolen automatically with the latest technology. We automatically bind the video and audio tag prevent user from accessing the real video file which make your video safe from special algorithm


== Installation ==

1. Upload `defaprotector` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently asked questions ==

= A question that someone might have =

An answer to that question.

What do these software doing?

It protect your html5 video from download but doesn't protect from screen recording

Why some browser cannot play the video?

Because Defa Protector doesn't send you  a real video files making some browser video player cannot play

What is nojavascript.php and spoof.php on juthawong.com does?

nojavascript.php and spoof.php is just a file redirect to stop hackers from spoofing useragent and hacking the video for download. You can remove it as you want but it will lessen your video security.


Encounter Problems ? 

Open ticket or read wiki at Sourceforge.
http://sourceforge.net/p/defaprotecthtml5videodownload/


== Screenshots ==

1. 
2. 

== Changelog ==



== Upgrade notice ==



== Arbitrary section 1 ==



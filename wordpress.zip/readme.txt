=== Defa Protector Platinum ===
Contributors: Juthawong Naisanguansee
Donate link: http://www.juthawong.com/donate
Tags: Defa Protector,Protect HTML5 Video From Downloaded,chrome,browser,idm,download,video,grabber,stop,download,prevent,block,firewall,prevent download,protect video download,stop video download,disable video download
Requires at least: 3.3
Tested up to: 4.2
Stable tag: 6.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Protect your html5 video from being downloaded or stolen automatically with the latest technology. 

== Description ==

Protect your html5 video from being downloaded or stolen automatically with the latest technology. We automatically bind the video and audio tag prevent user from accessing the real video file which make your video safe from special algorithm

For More Security and Hide MediaFallback Link. Please use Secure HTML5 Video Player

Defa Protector FAQ : http://www.juthawong.com/defa-protector-faq/


== Installation ==

1. Upload `defaprotector` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently asked questions ==

= A question that someone might have =


An answer to that question.


What do these software doing?

It protect your html5 video from download but doesn't protect from screen recording

I see a media fallback link ( unprotect video link ) in video. How should I fix?

These are usually comes with Wordpress Built in Video Player. Change it to Secure HTML5 Video Player instead. The problems gone and video load a lot faster

Why some browser cannot play the video?

Because Defa Protector doesn't send you  a real video files making some browser video player cannot play

What is nojavascript.php and spoof.php on juthawong.com does?

nojavascript.php and spoof.php is just a file redirect to stop hackers from spoofing useragent and hacking the video for download. You can remove it as you want but it will lessen your video security.


Encounter Problems ? 

Open ticket or read wiki at Sourceforge.
http://sourceforge.net/p/defaprotecthtml5videodownload/


== Screenshots ==

1. 
2. 

== Changelog ==
6.0 to 6.1 Quick Fixes : Error With Jquery making unexpected problems with other themes


== Upgrade notice ==



== Arbitrary section 1 ==



<?php
session_start();
//Written By Juthawong Naisanguansee
error_reporting(0);
ob_start();
?>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" >

# Defa-Protector-Protect-HTML5-Video-From-Download
Defa Protector is a php script that protect html5 video on your website from being downloaded.  The project aims to give a safe video protection all over the world.  Frequently asked question :  Defa Protector doesn’t send you a real video files which make some browser video player cannot load the video but we support most of the modern browser


How to use :

Put include('includetop.php'); at the most top of the content display page or script.

Put include('includebottom.php'); at the most bottom of the content display page or script.

For Wordpress Plugin and other files : http://sourceforge.net/projects/defaprotecthtml5videodownload/files/?source=navbar

If you like our project, Please Donate us : http://www.juthawong.com/donate 
